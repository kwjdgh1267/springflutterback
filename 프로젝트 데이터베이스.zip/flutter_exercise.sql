-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: flutter
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `exercise`
--

DROP TABLE IF EXISTS `exercise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exercise` (
  `id` bigint NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exercise`
--

LOCK TABLES `exercise` WRITE;
/*!40000 ALTER TABLE `exercise` DISABLE KEYS */;
INSERT INTO `exercise` VALUES (1,'벤치프레스','가슴'),(2,'숄더프레스','어깨'),(52,'덤벨 플라이','가슴'),(53,'푸시업','가슴'),(54,'인클라인 벤치 프레스','가슴'),(55,'디클라인 벤치 프레스','가슴'),(56,'케이블 크로스 오버','가슴'),(57,'펙 덱 플라이','가슴'),(58,'체스트 프레스 머신','가슴'),(59,'덤벨 풀오버','가슴'),(60,'푸시업 플라이','가슴'),(61,'밀리터리 프레스','어깨'),(62,'아놀드 프레스','어깨'),(63,'사이드 레터럴 레이즈','어깨'),(64,'프론트 레이즈','어깨'),(65,'벤트오버 레터럴 레이즈','어깨'),(66,'업라이즈 로우','어깨'),(67,'케이블 프론트 레이즈','어깨'),(68,'케이블 레터럴 레이즈','어깨'),(69,'리버스 펙 덱','어깨'),(70,'데드리프트','등'),(71,'풀업','등'),(72,'벤트오버 로우','등'),(73,'원암 덤벨 로우','등'),(74,'시티드 로우','등'),(75,'렛 풀다운','등'),(76,'티 바 로우','등'),(77,'하이퍼 익스텐션','등'),(78,'슈퍼맨','등'),(79,'스쿼트','하체'),(80,'런지','하체'),(81,'레그 프레스','하체'),(82,'레그 익스텐션','하체'),(83,'레그 컬','하체'),(84,'카프 레이즈','하체'),(85,'글루트 브리지','하체'),(86,'덤벨 스텝업','하체'),(87,'힙 쓰러스트','하체'),(88,'바벨 컬','팔'),(89,'덤벨 컬','팔'),(90,'해머 컬','팔'),(91,'트라이셉트 익스텐션','팔'),(92,'트라이셉트 딥','팔'),(93,'케이블 푸시다운','팔'),(94,'오버헤드 케이블 익스텐션','팔'),(95,'리버스 컬','팔'),(96,'컨센트레이션 컬','팔'),(97,'트라이셉트 킥백','팔');
/*!40000 ALTER TABLE `exercise` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-13 10:14:29
